// netlify/functions/leaderboard.js
const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_KEY = process.env.SUPABASE_KEY;

const headers = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type",
  "Content-Type": "application/json"
};

exports.handler = async function(event, context) {
  try {
    if (event.httpMethod === "OPTIONS") {
      return { statusCode: 204, headers: { ...headers, "Access-Control-Allow-Methods": "GET,POST,OPTIONS" }, body: "" };
    }
    if (!SUPABASE_URL || !SUPABASE_KEY) {
      return { statusCode: 500, headers, body: JSON.stringify({ error: "SUPABASE_URL or SUPABASE_KEY not set." }) };
    }
    const baseUrl = `${SUPABASE_URL}/rest/v1/leaderboard`;
    if (event.httpMethod === "GET") {
      const url = `${baseUrl}?select=*&order=score.desc&limit=50`;
      const resp = await fetch(url, { headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` }});
      const data = await resp.json();
      return { statusCode: 200, headers, body: JSON.stringify({ scores: data }) };
    }
    if (event.httpMethod === "POST") {
      let payload;
      try { payload = JSON.parse(event.body); } catch { payload = null; }
      if (!payload || typeof payload.score !== "number" || !payload.name) {
        return { statusCode: 400, headers, body: JSON.stringify({ error: "Invalid payload. Expect {name,score,mode}." }) };
      }
      const row = { name: payload.name, score: payload.score, mode: payload.mode || null };
      const insertResp = await fetch(baseUrl, {
        method: "POST",
        headers: {
          apikey: SUPABASE_KEY,
          Authorization: `Bearer ${SUPABASE_KEY}`,
          "Content-Type": "application/json",
          Prefer: "return=representation"
        },
        body: JSON.stringify(row)
      });
      const created = await insertResp.json();
      return { statusCode: 201, headers, body: JSON.stringify({ created }) };
    }
    return { statusCode: 405, headers, body: JSON.stringify({ error: "Method not allowed" }) };
  } catch (err) {
    return { statusCode: 500, headers, body: JSON.stringify({ error: String(err) }) };
  }
};