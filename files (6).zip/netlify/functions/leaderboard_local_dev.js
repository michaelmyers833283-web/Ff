// netlify/functions/leaderboard_local_dev.js
const fs = require('fs');
const PATH = './.data/leaderboard.json';
const headers = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type",
  "Content-Type": "application/json"
};

function ensureFile() {
  if (!fs.existsSync('.data')) fs.mkdirSync('.data');
  if (!fs.existsSync(PATH)) fs.writeFileSync(PATH, JSON.stringify([]));
}
function readAll() { ensureFile(); return JSON.parse(fs.readFileSync(PATH, 'utf8') || '[]'); }
function writeAll(arr) { ensureFile(); fs.writeFileSync(PATH, JSON.stringify(arr, null, 2)); }

exports.handler = async function(event, context) {
  try {
    if (event.httpMethod === "OPTIONS") {
      return { statusCode: 204, headers: { ...headers, "Access-Control-Allow-Methods": "GET,POST,OPTIONS" }, body: "" };
    }
    if (event.httpMethod === "GET") {
      const scores = readAll();
      scores.sort((a, b) => b.score - a.score);
      return { statusCode: 200, headers, body: JSON.stringify({ scores }) };
    }
    if (event.httpMethod === "POST") {
      const payload = JSON.parse(event.body || "{}");
      if (!payload || !payload.name || typeof payload.score !== 'number') {
        return { statusCode: 400, headers, body: JSON.stringify({ error: "Invalid payload" }) };
      }
      const scores = readAll();
      const row = { id: Date.now(), name: payload.name, score: payload.score, mode: payload.mode || null, created_at: new Date().toISOString() };
      scores.push(row);
      writeAll(scores);
      return { statusCode: 201, headers, body: JSON.stringify({ created: row }) };
    }
    return { statusCode: 405, headers, body: JSON.stringify({ error: "Method not allowed" }) };
  } catch (err) {
    return { statusCode: 500, headers, body: JSON.stringify({ error: String(err) }) };
  }
};