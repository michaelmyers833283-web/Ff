// examples/animation_integration_example.js
// Example: integrate GLTFAnimator into your three.js preview and game loop
import * as THREE from 'https://unpkg.com/three@0.161.0/build/three.module.js';
import { GLTFAnimator } from '../src/gltf-animation.js';

async function runDemo() {
  const threeview = document.getElementById('threeview');
  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
  threeview.appendChild(renderer.domElement);
  renderer.setSize(400, 300);

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(45, 400/300, 0.1, 1000);
  camera.position.set(0, 1.6, 3);

  const light = new THREE.DirectionalLight(0xffffff, 1.0);
  light.position.set(2,4,2);
  scene.add(light);
  scene.add(new THREE.AmbientLight(0x404040, 1.2));

  const animator = new GLTFAnimator(scene);

  // Ensure assets/models/foxy.glb exists and contains named animation clips
  try {
    const foxy = await animator.loadModel('assets/models/foxy.glb', { name: 'Foxy', scale: 1.0 });
    animator.setClipMapping(foxy, { Idle: 'Idle', Walk: 'Walk', Attack: 'Attack', Jumpscare: 'Jumpscare', Hallucinate: 'Hallucinate' });
    animator.playState(foxy, 'Idle');
  } catch (e) {
    console.warn('Failed to load demo model (assets/models/foxy.glb). Add your GLB or skip preview.', e);
  }

  const clock = new THREE.Clock();
  function animate() {
    requestAnimationFrame(animate);
    const dt = clock.getDelta();
    animator.update(dt);
    renderer.render(scene, camera);
  }
  animate();
}
runDemo();