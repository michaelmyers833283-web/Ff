```markdown
Additions:
- Rear door & Rear camera mechanic implemented. Close Rear Door (desktop button or mobile 'Rear Door') to block animatronics that go BehindOffice.
- Mobile controls included in index.html (bottom overlay). Buttons map to desktop controls.
- Debug helpers:
  - window.NGP_Debug.listModelClips('foxy') // prints clip names for the foxy model (replace key)
  - window.NGP_Debug.suggestClipMappingFromModel(Assets.models.foxy) // guesses mapping from clip names (if model loaded)
  - window.NGP_Debug.buildSetClipMappingSnippet('foxy', mapping) // builds setClipMapping snippet

Testing locally:
1. Add models/audio/sprites to assets/ as listed in assets/manifest.json.
2. Serve the folder to avoid CORS issues:
   python -m http.server 8000
   open http://localhost:8000
3. Open browser console for logs and errors. Use the NGP_Debug helpers to inspect model clip names.
4. Use mobile device or browser device toolbar to test mobile overlay controls.
5. To create a ZIP: run scripts/create_release_zip.sh (ensure zip is installed).