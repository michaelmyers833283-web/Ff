#!/usr/bin/env bash
# Create a zip release of the repository
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
RELEASE_DIR="release"
DATE="$(date +%Y%m%d_%H%M%S)"
ZIP_NAME="night-guard-pro-${DATE}.zip"
rm -rf "$RELEASE_DIR"
mkdir -p "$RELEASE_DIR"
INCLUDE=("index.html" "style.css" "main.js" "README.md" "assets" "src" "netlify" "examples")
if ! command -v zip >/dev/null 2>&1; then
  echo "zip not found; install zip or create archive manually."
  exit 1
fi
zip -r "$RELEASE_DIR/$ZIP_NAME" "${INCLUDE[@]}" -x "*.git*" "*.DS_Store" "node_modules/*" ".github/*" "scripts/*" "release/*" ".env" ".env.*"
echo "Release created: $RELEASE_DIR/$ZIP_NAME"