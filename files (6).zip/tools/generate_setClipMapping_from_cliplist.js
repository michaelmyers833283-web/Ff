#!/usr/bin/env node
/**
 * tools/generate_setClipMapping_from_cliplist.js
 *
 * Input: mappings_input.json
 * Format example:
 * {
 *   "foxy": ["Idle","Walk","Sprint","Attack","Jumpscare"],
 *   "freddy": ["Idle","Walk","Attack","Jumpscare"]
 * }
 *
 * Output: writes to stdout JS code that sets mapping variables for use after animator.loadModel(...)
 *
 * Usage:
 *   node tools/generate_setClipMapping_from_cliplist.js mappings_input.json > mappings_snippet.js
 */

const fs = require('fs');
const path = require('path');

function loadJson(file) {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (e) {
    console.error('Failed to load JSON:', e.message);
    process.exit(1);
  }
}

// Heuristic mapping order of preference
const STATES = ['Idle','Walk','Run','Sprint','Attack','Jumpscare','Hallucinate','Sit','Blink','Death'];

function suggestMapping(clips) {
  const mapping = {};
  const lowerClips = clips.map(c => c.toLowerCase());
  for (const s of STATES) {
    // exact match
    let idx = lowerClips.indexOf(s.toLowerCase());
    if (idx >= 0) { mapping[s] = clips[idx]; continue; }
    // substring match
    idx = lowerClips.findIndex(c => c.includes(s.toLowerCase()));
    if (idx >= 0) { mapping[s] = clips[idx]; continue; }
    // more fuzzy: start-with
    idx = lowerClips.findIndex(c => c.startsWith(s.toLowerCase()));
    if (idx >= 0) { mapping[s] = clips[idx]; continue; }
    // skip if none found
  }
  return mapping;
}

function buildSnippet(all) {
  const lines = [];
  lines.push('// Generated mapping snippet');
  lines.push('// For each model key use the corresponding animObj reference returned by animator.loadModel()');
  lines.push('// Example: const foxy_animObj = animator.loaded.find(a => a.name === "foxy" || (a.url && a.url.includes("foxy")));');
  lines.push('');
  for (const [key, clips] of Object.entries(all)) {
    const varName = `${key.replace(/[^A-Za-z0-9_]/g,'_')}_animObj`;
    const mapping = suggestMapping(clips || []);
    lines.push(`// model: ${key}`);
    lines.push(`// find animObj for this model (adjust search if needed)`);
    lines.push(`const ${varName} = animator.loaded.find(a => (a.name && a.name.toLowerCase() === '${key.toLowerCase()}') || (a.url && a.url.includes('${key}')));`);
    lines.push(`if (${varName}) {`);
    lines.push(`  animator.setClipMapping(${varName}, ${JSON.stringify(mapping, null, 2)});`);
    lines.push(`} else {`);
    lines.push(`  console.warn('AnimObj not found for model key: ${key}');`);
    lines.push(`}`);
    lines.push('');
  }
  return lines.join('\n');
}

// main
if (process.argv.length < 3) {
  console.error('Usage: node generate_setClipMapping_from_cliplist.js <mappings_input.json>');
  process.exit(1);
}

const input = loadJson(process.argv[2]);
const snippet = buildSnippet(input);
console.log(snippet);