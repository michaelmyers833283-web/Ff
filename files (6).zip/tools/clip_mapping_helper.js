// Run in browser console on your game's page after assets load.
// Example usage:
//   await listAllClipNames(); // prints clips for each loaded model and shows on-screen
//   const mappings = suggestMappingsForAll(); // returns mapping suggestions object
//   const snippets = buildSetClipMappingSnippets(mappings); // returns string snippets to paste into init code
(async function() {
  window.ClipMapHelper = {
    listClipNamesForModel: function(modelKey) {
      try {
        const gltf = (window.Assets && window.Assets.models && window.Assets.models[modelKey]) || null;
        if (!gltf) {
          console.warn('Model not found in Assets.models:', modelKey);
          return [];
        }
        const names = (gltf.animations || []).map(c => c.name);
        console.log(`Clips for ${modelKey}:`, names);
        return names;
      } catch (e) {
        console.error('Error listing clips for', modelKey, e);
        return [];
      }
    },
    listAllClipNames: function() {
      const manifest = (window.Assets && window.Assets.manifest) || null;
      const out = {};
      if (!manifest || !manifest.models) {
        console.warn('No assets manifest available at window.Assets.manifest');
        return out;
      }
      for (const key of Object.keys(manifest.models)) {
        out[key] = this.listClipNamesForModel(key);
      }
      console.log('All clip names:', out);
      return out;
    },
    suggestMappingFromClips: function(clipNames) {
      // simple match list
      const states = ['Idle','Walk','Run','Sprint','Attack','Jumpscare','Hallucinate','Sit','Blink'];
      const mapping = {};
      for (const s of states) {
        const found = clipNames.find(c => c.toLowerCase().includes(s.toLowerCase()));
        if (found) mapping[s] = found;
      }
      return mapping;
    },
    suggestMappingsForAll: function() {
      const manifest = (window.Assets && window.Assets.manifest) || null;
      if (!manifest || !manifest.models) { console.warn('No manifest'); return {}; }
      const result = {};
      for (const k of Object.keys(manifest.models)) {
        const clips = this.listClipNamesForModel(k);
        result[k] = this.suggestMappingFromClips(clips || []);
      }
      console.log('Suggested mappings:', result);
      return result;
    },
    buildSetClipMappingSnippets: function(mappings) {
      // mappings: { modelKey: { state: clipName, ... }, ... }
      let out = '';
      for (const [modelKey, map] of Object.entries(mappings || {})) {
        const varName = `${modelKey.replace(/[^A-Za-z0-9_]/g,'_')}_animObj`;
        out += `// For model key "${modelKey}"\n`;
        out += `// assume you have: const ${varName} = animator.loaded.find(a => a.url && a.url.includes('${modelKey}'));\n`;
        out += `animator.setClipMapping(${varName}, ${JSON.stringify(map, null, 2)});\n\n`;
      }
      console.log('Mapping snippets (paste into your init code):\n\n' + out);
      return out;
    }
  };
  console.log('ClipMapHelper installed. Use window.ClipMapHelper.listAllClipNames(), suggestMappingsForAll(), buildSetClipMappingSnippets(...)');
})();