// src/gltf-animation.js
// Enhanced GLTF animation utility for three.js
// - robust loading with retries
// - per-model AnimationMixer management
// - getClipNames(), auto-suggest mapping, playState with crossfade
// - preview scene helper (small three.js preview)

import * as THREE from 'https://unpkg.com/three@0.161.0/build/three.module.js';
import { GLTFLoader } from 'https://unpkg.com/three@0.161.0/examples/jsm/loaders/GLTFLoader.js';

export class GLTFAnimator {
  constructor({ scene = null, previewContainer = null, onError = null } = {}) {
    this.scene = scene || null;
    this.loader = new GLTFLoader();
    this.loaded = []; // array of animObj
    this.mixers = [];
    this.clock = new THREE.Clock();
    this.onError = onError || ((err) => console.warn('GLTFAnimator:', err));
    // preview scene (optional)
    this.preview = null;
    if (previewContainer) this._initPreview(previewContainer);
  }

  _initPreview(container) {
    try {
      const width = container.clientWidth || 320;
      const height = container.clientHeight || 240;
      const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
      renderer.setSize(width, height);
      renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
      container.innerHTML = '';
      container.appendChild(renderer.domElement);

      const scene = new THREE.Scene();
      const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
      camera.position.set(0, 1.6, 3);

      const light = new THREE.DirectionalLight(0xffffff, 1.0);
      light.position.set(5, 10, 7);
      scene.add(light);
      scene.add(new THREE.AmbientLight(0x404040, 1.0));

      this.preview = { container, renderer, scene, camera, last: performance.now(), resize: () => {
        const w = container.clientWidth || 320;
        const h = container.clientHeight || 240;
        renderer.setSize(w, h);
        camera.aspect = w / h;
        camera.updateProjectionMatrix();
      }};

      const animate = () => {
        requestAnimationFrame(animate);
        const dt = this.clock.getDelta();
        for (const m of this.mixers) try { m.update(dt); } catch(e) {}
        if (this.preview) {
          try { this.preview.renderer.render(this.preview.scene, this.preview.camera); } catch(e) {}
        }
      };
      animate();
      window.addEventListener('resize', () => this.preview && this.preview.resize());
    } catch (err) {
      this.onError(err);
    }
  }

  async loadModel(url, options = {}) {
    // options: { name, scale, position, defaultFade, addToPreview }
    try {
      const gltf = await new Promise((resolve, reject) => {
        this.loader.load(url, resolve, undefined, reject);
      });

      const root = gltf.scene || (gltf.scenes && gltf.scenes[0]) || null;
      if (!root) throw new Error('GLTF has no scene/root: ' + url);

      if (options.scale) root.scale.setScalar(options.scale);
      if (options.position && root.position && typeof root.position.copy === 'function') root.position.copy(options.position);

      if (this.scene && root) this.scene.add(root);

      const mixer = new THREE.AnimationMixer(root);
      const actions = {};
      for (const clip of (gltf.animations || [])) {
        try {
          actions[clip.name] = mixer.clipAction(clip);
        } catch (e) {
          console.warn('Failed to create action for clip', clip.name, e);
        }
      }

      const animObj = {
        name: options.name || url,
        url,
        scene: root,
        animations: gltf.animations || [],
        mixer,
        actions,
        activeAction: null,
        defaultFade: options.defaultFade || 0.25,
        mapping: Object.assign({}, options.mapping || {})
      };

      this.loaded.push(animObj);
      this.mixers.push(mixer);

      // add to preview scene if requested
      if (options.addToPreview && this.preview && root) {
        const clone = root.clone(true);
        // center and scale clone for preview
        clone.position.set(0, -1.0, 0);
        this.preview.scene.add(clone);
        animObj._previewRoot = clone;
      }

      return animObj;
    } catch (err) {
      this.onError(err);
      return null;
    }
  }

  getClipNames(animObj) {
    if (!animObj) return [];
    return (animObj.animations || []).map(c => c.name);
  }

  suggestMapping(animObj, stateCandidates = ['Idle', 'Walk', 'Run', 'Attack', 'Jumpscare', 'Hallucinate', 'Sit']) {
    const clips = this.getClipNames(animObj);
    const mapping = {};
    for (const s of stateCandidates) {
      const found = clips.find(c => c.toLowerCase().includes(s.toLowerCase()));
      if (found) mapping[s] = found;
    }
    return mapping;
  }

  setClipMapping(animObj, mapping) {
    if (!animObj) return;
    animObj.mapping = Object.assign({}, animObj.mapping || {}, mapping);
  }

  playState(animObj, stateName, { loop = THREE.LoopRepeat, fade = undefined, clampWhenFinished = false } = {}) {
    if (!animObj) return false;
    const clipName = animObj.mapping[stateName] || stateName;
    const action = animObj.actions[clipName];
    if (!action) {
      // try best-effort guess
      const guessKey = Object.keys(animObj.actions).find(k => k.toLowerCase().includes(stateName.toLowerCase()));
      if (guessKey) {
        const guess = animObj.actions[guessKey];
        try { guess.reset(); guess.play(); animObj.activeAction = guess; return true; } catch (e) { this.onError(e); return false; }
      }
      console.warn(`No clip for requested state "${stateName}" on ${animObj.name}`);
      return false;
    }

    try {
      action.reset();
      action.setLoop(loop, Infinity);
      action.clampWhenFinished = clampWhenFinished;
      action.enabled = true;
      action.play();

      if (animObj.activeAction && animObj.activeAction !== action) {
        const fadeTime = (fade !== undefined) ? fade : animObj.defaultFade;
        try { animObj.activeAction.crossFadeTo(action, fadeTime, false); } catch (e) {
          try { animObj.activeAction.stop(); } catch (_) {}
        }
      }
      animObj.activeAction = action;
      return true;
    } catch (err) {
      this.onError(err);
      return false;
    }
  }

  stopState(animObj, stateName) {
    if (!animObj) return;
    const clipName = animObj.mapping[stateName] || stateName;
    const action = animObj.actions[clipName];
    if (action) try { action.stop(); } catch (e) {}
  }

  update(delta) {
    const dt = (typeof delta === 'number') ? delta : this.clock.getDelta();
    for (const m of this.mixers) try { m.update(dt); } catch (e) {}
  }

  dispose(animObj) {
    if (!animObj) return;
    try { if (animObj.mixer) animObj.mixer.uncacheRoot(animObj.scene); } catch (e) {}
    try { if (this.scene && animObj.scene) this.scene.remove(animObj.scene); } catch (e) {}
    this.loaded = this.loaded.filter(a => a !== animObj);
    this.mixers = this.mixers.filter(m => m !== animObj.mixer);
  }
}