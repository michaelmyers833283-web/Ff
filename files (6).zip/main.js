// main.js (updated)
// Integrates GLTFAnimator, provides an animation-editor UI, improves Anim-Sim Night Guard AI,
// adds runtime error capture to on-screen log, and mobile controls mapping.

import * as THREE from 'https://unpkg.com/three@0.161.0/build/three.module.js';
import { GLTFAnimator } from './src/gltf-animation.js';

// ---------------------- Utility & UI helpers ----------------------
function $(id) { return document.getElementById(id); }
function logToElement(el, msg) {
  if (!el) return;
  el.innerHTML = `[${new Date().toLocaleTimeString()}] ${msg}<br>` + el.innerHTML;
}

// Capture runtime errors and unhandled rejections and print to on-screen UI
window.onerror = function(message, source, lineno, colno, error) {
  const el = document.querySelector('#game-log') || document.querySelector('body');
  const msg = `ERROR: ${message} at ${source}:${lineno}:${colno} ${error ? error.stack : ''}`;
  console.error(msg);
  logToElement(el, msg);
};
window.onunhandledrejection = function(e) {
  const el = document.querySelector('#game-log') || document.querySelector('body');
  const msg = `UNHANDLED PROMISE REJECTION: ${e.reason}`;
  console.error(msg);
  logToElement(el, msg);
};

// ---------------------- Assets & animator ----------------------
const Assets = {
  manifest: null,
  models: {},
  audio: {},
  async loadManifest() {
    try {
      const res = await fetch('assets/manifest.json');
      this.manifest = await res.json();
      return this.manifest;
    } catch (e) {
      console.warn('Failed to load manifest.json', e);
      return null;
    }
  },
  async loadAll(onProgress = null) {
    await this.loadManifest();
    if (!this.manifest) return;
    // load gltf models
    const loader = new THREE.GLTFLoader?.() || null;
    for (const [k, url] of Object.entries(this.manifest.models || {})) {
      try {
        // use fetch+arrayBuffer if GLTFLoader not available in global
        const gltf = await new Promise((resolve, reject) => {
          const L = new THREE.GLTFLoader();
          L.load(url, resolve, undefined, (err) => {
            console.warn('Model load failed', url, err);
            resolve(null);
          });
        });
        this.models[k] = gltf;
      } catch (e) {
        console.warn('Failed model', k, e);
        this.models[k] = null;
      }
      onProgress && onProgress({ type: 'model', key: k });
    }
    // load audio
    for (const [k, url] of Object.entries(this.manifest.audio || {})) {
      try {
        const a = new Audio(url);
        a.preload = 'auto';
        this.audio[k] = a;
      } catch (e) {
        console.warn('Audio load failed', url, e);
        this.audio[k] = null;
      }
      onProgress && onProgress({ type: 'audio', key: k });
    }
  },
  playSound(name, opts = { volume: 1 }) {
    const a = this.audio[name];
    if (!a) return;
    try { const s = a.cloneNode(); s.volume = opts.volume ?? 1; s.play().catch(()=>{}); return s; } catch {}
  },
  playMusic(name) {
    const a = this.audio[name];
    if (!a) return;
    try { this.music?.pause(); this.music = a.cloneNode(); this.music.loop = true; this.music.volume = 0.6; this.music.play().catch(()=>{}); } catch {}
  },
  stopMusic() { try { this.music?.pause(); this.music = null; } catch {} }
};

// create a small preview container and animator
let animator = null;

// ---------------------- Animation Editor UI helpers ----------------------
function createAnimationEditorPanel(root) {
  // create a simple panel to show loaded models, clip lists, and mapping buttons
  const panel = document.createElement('div');
  panel.style.width = '320px';
  panel.style.padding = '10px';
  panel.style.background = 'rgba(10,10,14,0.9)';
  panel.style.color = '#fff';
  panel.style.borderRadius = '8px';
  panel.style.maxHeight = '480px';
  panel.style.overflow = 'auto';

  panel.innerHTML = `<h3>Animation Editor</h3>
    <div id="anim-editor-models"></div>
    <div style="margin-top:8px">
      <button id="anim-editor-refresh">Refresh Clips</button>
      <button id="anim-editor-autoset">Auto-Suggest Mappings</button>
    </div>
    <div id="anim-editor-snippet" style="margin-top:8px;font-size:12px;white-space:pre-wrap;"></div>
  `;
  root.appendChild(panel);

  $('anim-editor-refresh').addEventListener('click', async () => {
    await populateModelClipLists();
  });
  $('anim-editor-autoset').addEventListener('click', () => {
    autoSuggestMappings();
  });
  return panel;
}

async function populateModelClipLists() {
  const container = $('anim-editor-models');
  container.innerHTML = '';
  if (!animator) {
    container.innerHTML = '<div>No animator loaded.</div>';
    return;
  }
  for (const animObj of animator.loaded) {
    const name = animObj.name || 'model';
    const box = document.createElement('div');
    box.style.marginBottom = '8px';
    box.style.borderTop = '1px solid #333';
    box.innerHTML = `<strong>${name}</strong><div class="clip-list" id="clips-${name}"></div>
      <div style="margin-top:4px"><button data-model="${name}" class="play-idle">Play Idle</button>
      <button data-model="${name}" class="play-walk">Play Walk</button>
      <button data-model="${name}" class="apply-mapping">Apply Mapping</button></div>`;
    container.appendChild(box);

    const clipsDiv = box.querySelector(`#clips-${name}`);
    const clips = (animObj.animations || []).map(c => c.name);
    clipsDiv.innerHTML = clips.length ? clips.map(c => `<div>${c}</div>`).join('') : '<div style="color:#999">No clips</div>';

    box.querySelector('.play-idle').addEventListener('click', () => {
      animator.playState(animObj, 'Idle', { loop: THREE.LoopRepeat });
    });
    box.querySelector('.play-walk').addEventListener('click', () => {
      animator.playState(animObj, 'Walk', { loop: THREE.LoopRepeat });
    });
    box.querySelector('.apply-mapping').addEventListener('click', () => {
      const mapping = animator.suggestMapping(animObj);
      animator.setClipMapping(animObj, mapping);
      $('anim-editor-snippet').textContent = buildMappingSnippet(animObj, mapping);
      logToElement(document.querySelector('#game-log'), `Applied mapping for ${animObj.name}: ${JSON.stringify(mapping)}`);
    });
  }
}

function buildMappingSnippet(animObj, mapping) {
  const nameVar = animObj.name.replace(/[^A-Za-z0-9_]/g, '_') + '_animObj';
  const lines = [];
  lines.push(`// Use this snippet to set mapping for ${animObj.name}`);
  lines.push(`// assume 'animator' is your GLTFAnimator and ${nameVar} is the returned animObj from animator.loadModel(...)`);
  lines.push(`animator.setClipMapping(${nameVar}, ${JSON.stringify(mapping, null, 2)});`);
  return lines.join('\n');
}

function autoSuggestMappings() {
  if (!animator) return;
  const snippets = [];
  for (const animObj of animator.loaded) {
    const mapping = animator.suggestMapping(animObj);
    animator.setClipMapping(animObj, mapping);
    snippets.push(buildMappingSnippet(animObj, mapping));
  }
  $('anim-editor-snippet').textContent = snippets.join('\n\n');
  logToElement(document.querySelector('#game-log'), 'Auto-suggested mappings applied to loaded models.');
}

// expose debug helper to window
window.NGP_Debug = {
  listModelClips: async (modelKey) => {
    if (!Assets.models[modelKey]) { console.warn('Model not loaded:', modelKey); return []; }
    const gltf = Assets.models[modelKey];
    const clipNames = (gltf && gltf.animations) ? gltf.animations.map(c => c.name) : [];
    console.log(`Clips for model ${modelKey}:`, clipNames);
    const el = document.querySelector('#game-log');
    if (el) logToElement(el, `Clips for ${modelKey}: ${clipNames.join(', ')}`);
    return clipNames;
  },
  autoSuggestMappingsForAll: () => autoSuggestMappings()
};

// ---------------------- Night Guard AI (Anim-Sim) ----------------------
// Improved guard AI used in Anim-Sim: state machine, predictive closing, cooldowns
class NightGuardAI {
  constructor({ initialSkill = 44 } = {}) {
    this.skill = initialSkill; // 1..100, higher means smarter
    this.state = 'patrol'; // patrol, monitor, close_door, investigate, rest
    this.lastSeen = { pos: null, time: 0 };
    this.cooldowns = { closeDoor: 0, scan: 0, investigate: 0 };
    this.patternMemory = []; // last N player positions to predict path
  }

  // call every tick with dt (seconds) and observable info
  tick(dt, observables) {
    // decrement cooldowns
    for (const k of Object.keys(this.cooldowns)) this.cooldowns[k] = Math.max(0, this.cooldowns[k] - dt);

    // remember pattern
    if (observables.playerPos) {
      this.patternMemory.push(observables.playerPos);
      if (this.patternMemory.length > 8) this.patternMemory.shift();
    }

    // basic reactive rules:
    // - if player seen near officedoor recently, increase probability to close doors
    // - if pattern shows repeated hallway use, pre-emptively close that door more often
    const nearOffice = (observables.playerNearOffice) ? 1.0 : 0.0;
    const lastPattern = this._predictNextFromPattern();
    // decide actions based on skill and randomness
    const rand = Math.random();
    // scanning behavior
    if (this.cooldowns.scan <= 0 && (rand < 0.25 + this.skill / 150)) {
      this.cooldowns.scan = 3 + (1 - this.skill / 100) * 5; // smarter guards scan more often
      return { action: 'scan', details: { view: 'cameras' } };
    }
    // close doors if prediction suggests approach or recently seen near office
    if (this.cooldowns.closeDoor <= 0 && (nearOffice > 0.5 || lastPattern === 'LeftHall' || lastPattern === 'RightHall') && rand < 0.6 + this.skill / 200) {
      this.cooldowns.closeDoor = 6 + (1 - this.skill / 100) * 6;
      // choose which doors to close: if lastPattern suggests LeftHall -> close left; else close both
      const closeLeft = (lastPattern === 'LeftHall' && Math.random() < 0.9);
      const closeRight = (lastPattern === 'RightHall' && Math.random() < 0.9);
      return { action: 'close_doors', details: { left: closeLeft || rand < 0.1, right: closeRight || rand < 0.1 } };
    }
    // investigate sound/jump if signal
    if (observables.specialEvent && this.cooldowns.investigate <= 0 && rand < 0.5 + this.skill / 200) {
      this.cooldowns.investigate = 8;
      return { action: 'investigate', details: { where: observables.eventPos || 'unknown' } };
    }
    // default monitor
    return { action: 'monitor', details: {} };
  }

  _predictNextFromPattern() {
    if (this.patternMemory.length < 3) return null;
    const last = this.patternMemory[this.patternMemory.length - 1];
    // naive: if player used LeftHall > RightHall recently, predict left
    const counts = this.patternMemory.reduce((acc, v) => { acc[v] = (acc[v] || 0) + 1; return acc; }, {});
    if ((counts['LeftHall'] || 0) > (counts['RightHall'] || 0) + 1) return 'LeftHall';
    if ((counts['RightHall'] || 0) > (counts['LeftHall'] || 0) + 1) return 'RightHall';
    return null;
  }
}

// ---------------------- Game runtime (Anim-Sim integrations) ----------------------
const GameRuntime = {
  // when initiating game, create the GLTF animator preview & editor
  async initAnimationSystem(previewContainer, editorContainer) {
    if (!animator) {
      animator = new GLTFAnimator({ previewContainer });
    }
    // load models into animator preview as well (if not loaded)
    const manifest = await fetch('assets/manifest.json').then(r => r.json()).catch(() => null);
    if (!manifest) return;
    // load each model into animator and add to preview
    for (const [key, url] of Object.entries(manifest.models || {})) {
      if (!animator.loaded.find(a => a.url === url)) {
        const animObj = await animator.loadModel(url, { name: key, addToPreview: true, scale: 1.0 });
        if (!animObj) console.warn('Animator failed to load', key);
      }
    }
    // create animation editor panel inside provided container
    if (editorContainer) createAnimationEditorPanel(editorContainer);
    // initial populate
    await populateModelClipLists();
  },

  // improved Anim-Sim guard AI integrated
  async startAnimSimGame(root) {
    // UI elements
    const canvas = root.querySelector('#game-canvas');
    const logEl = root.querySelector('#game-log');
    const clockEL = root.querySelector('#clock-status');
    const ctx = canvas.getContext('2d');

    logToElement(logEl, 'Starting Anim-Sim with improved Guard AI...');

    // instantiate guard
    const guard = new NightGuardAI({ initialSkill: 64 });

    // anim player state
    let player = { pos: 'Stage', time: 360, specialAvailable: true, running: true };

    // mobile buttons mapping is already wired elsewhere; we add tactical simulation
    root.querySelector('#animMoveBtn')?.addEventListener('click', () => {
      const order = ['Stage', 'LeftHall', 'BackStage', 'OfficeDoor', 'Office'];
      const idx = order.indexOf(player.pos);
      player.pos = order[Math.min(order.length - 1, idx + 1)];
      logToElement(logEl, `Anim moved to ${player.pos}`);
    });
    root.querySelector('#animAttackBtn')?.addEventListener('click', () => {
      if (player.pos !== 'OfficeDoor') { logToElement(logEl, 'Not at office door.'); return; }
      logToElement(logEl, 'Attempting attack...');
      // guard decides
      const guardDecision = guard.tick(0.1, { playerPos: player.pos, playerNearOffice: true, specialEvent: false });
      if (guardDecision.action === 'close_doors') {
        logToElement(logEl, 'Guard managed to close doors in time. Attack blocked!');
      } else {
        logToElement(logEl, 'Attack success: entered office!');
        player.running = false;
        updateLeaderboard({ name: 'AnimPlayer', score: Math.round(360 - player.time), mode: 'anim-sim' });
      }
    });
    root.querySelector('#animSpecialBtn')?.addEventListener('click', () => {
      if (!player.specialAvailable) { logToElement(logEl, 'Special not ready.'); return; }
      player.specialAvailable = false;
      logToElement(logEl, 'Used special: hallucination!');
      // cause guard to investigate incorrectly next tick (simulate confusion)
    });

    let last = performance.now();
    function loop(now) {
      if (!player.running) return;
      const dt = Math.min(1, (now - last) / 1000);
      last = now;
      player.time -= dt;
      clockEL.textContent = `(0${6 - Math.floor(player.time / 60)}:${('0' + Math.round(player.time % 60)).slice(-2)})`;

      // guard tick with observables
      const observables = {
        playerPos: player.pos,
        playerNearOffice: player.pos === 'OfficeDoor' || player.pos === 'Office',
        specialEvent: !player.specialAvailable
      };
      const decision = guard.tick(dt, observables);
      // respond to decision: log and potentially close doors or scan
      if (decision.action === 'scan') {
        logToElement(logEl, 'Guard scans cameras.');
      } else if (decision.action === 'close_doors') {
        logToElement(logEl, `Guard preemptively closed doors (left:${decision.details.left}, right:${decision.details.right}).`);
      } else if (decision.action === 'investigate') {
        logToElement(logEl, `Guard investigates ${decision.details.where}`);
      } else {
        // monitor
      }

      if (player.time <= 0) {
        logToElement(logEl, 'Time up — animatronic failed.');
        player.running = false;
      } else requestAnimationFrame(loop);
    }
    requestAnimationFrame(loop);

    function updateLeaderboard(row) {
      try {
        const scores = JSON.parse(localStorage.getItem('nightguard_leaderboard') || '[]');
        scores.push(row);
        localStorage.setItem('nightguard_leaderboard', JSON.stringify(scores));
      } catch (e) { console.warn('Leaderboard save failed', e); }
      // attempt remote post (best-effort)
      fetch('/.netlify/functions/leaderboard', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(row) }).catch(() => {});
    }
  }
};

// ---------------------- Initialization & wiring ----------------------
window.onload = async () => {
  // quick preloads (non-blocking)
  try { await Assets.loadAll(); } catch (e) { console.warn('Asset loading issue', e); }

  // build animation editor preview (if game UI present)
  const gameUI = document.getElementById('game-ui');
  if (gameUI) {
    // inject a small sidebar for animation editor once user opens game UI
  }

  // expose debug methods
  window.GltfAnimatorInstance = () => animator;
  window.GameRuntime = GameRuntime;

  // nothing auto-run: GameLoader in your main site should call GameRuntime.initAnimationSystem(...) before starting.
  console.log('main.js loaded. Use GameRuntime.initAnimationSystem(previewElement, editorElement) to initialize animation editor.');
  const logEl = document.querySelector('#game-log');
  if (logEl) logToElement(logEl, 'main.js ready; use animation editor to inspect models/clips.');
};