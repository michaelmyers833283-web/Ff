```markdown
# Leaderboard: Netlify Function + Supabase Setup

This guide explains how to configure the included Netlify function `netlify/functions/leaderboard.js` to store and retrieve leaderboard data using Supabase (Postgres). A local dev fallback `netlify/functions/leaderboard_local_dev.js` is included for the Netlify CLI.

1) Supabase setup
- Create a Supabase project at https://app.supabase.com
- Create a table `leaderboard` with the SQL:
  ```sql
  create table public.leaderboard (
    id bigserial primary key,
    name text not null,
    score integer not null,
    mode text,
    created_at timestamptz default now()
  );
  ```
- If you enable Row Level Security (RLS), use a service_role key for the function when inserting.

2) Environment variables (Netlify dashboard)
- SUPABASE_URL = https://<your-project>.supabase.co
- SUPABASE_KEY = <service_role_key_or_anon_key> (for inserts prefer service_role)

3) Deploy
- Push code to GitHub and connect repository to Netlify
- In Netlify site settings > Build & Deploy > Environment Variables add SUPABASE_URL and SUPABASE_KEY
- Netlify automatically picks up functions in `netlify/functions/`

4) API usage
- GET /.netlify/functions/leaderboard -> { scores: [...] }
- POST /.netlify/functions/leaderboard with JSON { name, score, mode } -> creates record

Local dev fallback
- Use `netlify dev` to run a local server with functions. The included local dev function stores data in `.data/leaderboard.json` and is for development only.

Security
- Protect SUPABASE_KEY in Netlify env vars.
- Validate and rate-limit incoming requests before production use.